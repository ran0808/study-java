package com.atm;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;
public class ATM {
    private ArrayList<Account> accounts = new ArrayList<>();//  []
    private Scanner sc=new Scanner(System.in);
    private  Account loginAcc;//记录登陆后的账户
    /*启动ATM系统，展示欢迎界面*/
    public void start() {
        while (true) {
            System.out.println("====欢迎您进入到ATM系统===");
            System.out.println("1.用户登录");
            System.out.println("2.用户开户");
            System.out.println("请选择：");
            int command = sc.nextInt();
            switch (command){
                case 1:
                    //用户登录
                    login();
                    break;
                case 2:
                    //用户开户
                    createAccount();
                    break;
                default:
                    System.out.println("没有该操作~~");
            }
        }

    }
    /*完成用户的登陆操作*/
    private  void login(){
        System.out.println("===登陆系统===");
        //判断是否有账户
        if (accounts.isEmpty()){
            System.out.println("抱歉，现在暂无账户，请开户后登陆~");
            return;
        }
        //进行登录操作
        while (true) {
            System.out.println("请您输入您的卡号：");
            String cardId=sc.next();
            Account acc = getAccountByCardId(cardId);
            if (acc == null) {
                System.out.println("您的卡号有误，确定是否再次输入：y or n");
                char ans=sc.next().charAt(0);
                if(ans=='y'){
                    continue;
                }
                else {
                 return;
                }
            }

            else{
                //卡号存在，接着让用户输入密码
                while (true) {
                    System.out.println("请您输入密码：");
                    String passWord = sc.next();
                    if(acc.getPassWord().equals(passWord)){
                        System.out.println("恭喜您，"+acc.getUserName()+"成功登陆，您的卡号是"+acc.getCardId());
                        loginAcc=acc;
                        //展示登录后的操作界面
                        showCommand();
                        return;
                    }
                    else{
                        System.out.println("您输入的密码有误，请重新输入：");
                    }
                }
            }
        }
    }
    private void showCommand(){
        while (true) {
            System.out.println(loginAcc.getUserName()+"您可以选择如下功能进行账户的处理：");
            System.out.println("1、查询账户");
            System.out.println("2、存款");
            System.out.println("3、取款");
            System.out.println("4、转账");
            System.out.println("5、密码修改");
            System.out.println("6、退出登陆");
            System.out.println("7、注销当前账户");
            System.out.println("请选择：");
            int command=sc.nextInt();
            switch (command){
                case 1:
                    //查询账户
                    showAccount();
                    break;
                case 2:
                    //存款
                    depositMoney();
                    break;
                case 3:
                    //取款
                    dropMoney();
                    break;
                case 4:
                    //转账
                    transferMoney();
                    break;

                case 5:
                    //修改密码
                    alterPassword();
                    return;
                case 6:
                    //退出登陆
                    System.out.println(loginAcc.getUserName()+"您退出系统成功！");
                    return;
                case 7:
                    //注销当前账户
                    if(deleteAccount()){
                        return;
                    }
                    break;
                default:
                    System.out.println("您输入的指令有误，请重新输入：");
            }
        }
    }

    private void alterPassword() {
        System.out.println("==修改密码==");
        while (true) {
            System.out.println("请您输入当前账户的密码:");
            String passWord = sc.next();
            if(loginAcc.getPassWord().equals(passWord)){
                System.out.println("密码匹配成功!");
                while (true) {
                    System.out.println("请输入新密码:");
                    String new_passWord = sc.next();
                    if(new_passWord.equals(loginAcc.getPassWord())){
                        System.out.println("密码未更改，请重新输入:");
                        continue;
                    }
                    //真正开始修改密码
                    System.out.println("请您确认密码：");
                    String ok_passWord = sc.next();
                    if (ok_passWord.equals(new_passWord)){
                        loginAcc.setPassWord(new_passWord);
                        System.out.println("您的密码修改成功!");
                        return;
                    }
                    else{
                        System.out.println("您两次输入的密码不一致，请重新输入：");
                    }
                }
            }
            else{
                System.out.println("您当前输入的密码不正确，确定是否继续修改？y / n:");
                String command = sc.next();
                switch (command){
                    case "y":
                        break;
                    default:
                        return;
                }
            }
        }
    }

    //注销账户的方法
    private boolean deleteAccount() {
        System.out.println("==销户操作==");
        System.out.println("请问是否确认销户？Y/N");
        String command = sc.next();
        switch (command){
            case "Y":
                //判断用户的账户中是否有钱
                if (loginAcc.getMoney()==0){
                    accounts.remove(loginAcc);
                    System.out.println("销户成功！");
                    return true;
                }
                else {
                    System.out.println("您的账户中仍有余额，销户失败~");
                    return false;
                }
            default:
                System.out.println("好的，您的账户保留~");
                return false;
        }
    }

    private void transferMoney() {
        System.out.println("==转账操作==");
        //判断是否有可转账对象
        if(accounts.size()<2){
            System.out.println("系统中不存在另一个账户，转账失败~");
            return;
        }
        //判断账户中是否有钱
        if(loginAcc.getMoney()==0){
            System.out.println("余额不足，无法转账");
            return;
        }
        //开始转账
        while (true) {
            System.out.println("请您输入对方的卡号：");
            String cardId = sc.next();
            //判断卡号是否正确
            Account acc = getAccountByCardId(cardId);
            if(acc == null){
                System.out.println("您输入的卡号有误，请重新输入：");
                continue;
            }
            if(acc.getCardId()==loginAcc.getCardId()) {
                System.out.println("不能向自己转钱，转钱操作失败~");
            }
            else{
                //对方账户存在，继续让用户认证姓氏
                System.out.println("请您输入*【"+acc.getUserName().substring(1)+"】姓氏");
                String prename = sc.next();
                //判断姓氏是否正确
                if(acc.getUserName().startsWith(prename)){
                    System.out.println("恭喜您"+loginAcc.getUserName()+"成功通过认证，可以开始转账操作：");
                    while (true) {
                        System.out.println("请您输入转账金额：");
                        double money = sc.nextDouble();
                        //判断金额是否没有超过余额
                        if(loginAcc.getMoney()>=money){
                            loginAcc.setMoney(loginAcc.getMoney()-money);
                            acc.setMoney(acc.getMoney()+money);
                            System.out.println("恭喜您完成转账"+money+"元,您的余额为"+loginAcc.getMoney());
                            return;
                        }
                        else {
                            System.out.println("您的余额不足，您最多可以转账："+loginAcc.getMoney()+"元");
                        }
                    }
                }
                else {
                    System.out.println("您的认证信息有误~");
                }
            }
        }
    }
    private void dropMoney() {
        System.out.println("==取钱操作==");
        if (loginAcc.getMoney()>100) {
            while (true) {
                System.out.println("请您输入您的取款金额：");
                double money = sc.nextDouble();
                //判断现有金额是否满足条件
                if (loginAcc.getLimit() >= money) {
                    if (loginAcc.getMoney() >= money) {
                        loginAcc.setMoney(loginAcc.getMoney() - money);
                        System.out.println("您取款了"+money+",您剩余存款为:"+loginAcc.getMoney());
                        break;
                    }
                    else
                    {
                        System.out.println("余额不足，操作失败~");
                    }
                }
                else {
                    System.out.println("取款金额超过限额，取款操作失败~");
                }
            }
        }
        else{
            System.out.println("您的余额不足100元，取款操作失败~");
            return;
            }
    }
    //存钱操作
    private void depositMoney() {
        System.out.println("==存钱操作==");
        System.out.println("请您输入存款金额：");
        double money = sc.nextDouble();
        //更新当前登录账户的余额
        double amount=loginAcc.getMoney()+money;
        loginAcc.setMoney(amount);
        System.out.println("恭喜您，"+loginAcc.getUserName()+"您存钱"+money+"元，现有金额："+loginAcc.getMoney());
    }
    //展示当前登陆的账户信息
    private void showAccount(){
        System.out.println("如下是当前账户信息：");
        System.out.println("卡号："+loginAcc.getCardId());
        System.out.println("户主："+loginAcc.getUserName());
        System.out.println("性别："+loginAcc.getSex());
        System.out.println("余额："+loginAcc.getMoney());
        System.out.println("每次取现额度："+loginAcc.getLimit());
    }
    /*设计方法完成用户开户*/
    private void createAccount(){
        System.out.println("===系统开户操作===");
        //1.创建账户对象，用于封装账户信息
        Account account = new Account();
        //2.需要用户输入自己的开户信息，赋值给账户对象
        System.out.println("请您输入您的账户名称：");
        String username=sc.next();
        account.setUserName(username);
        while (true) {
            System.out.println("请输入您的性别：");
            char sex=sc.next().charAt(0);
            if (sex =='男'||sex=='女'){
                account.setSex(sex);
                break;
            }else {
                System.out.println("您输入的性别有误！只能输入男或者女~");
            }
        }
        while (true) {
            System.out.println("请输入您的账户密码：");
            String password1 = sc.next();
            System.out.println("请再次输入您的密码");
            String password2 = sc.next();
            if(password2.equals(password1)) {   //是值相等
                System.out.println("密码录入成功！");
                account.setPassWord(password2);
                break;
            }
           else  {
                System.out.println("您输入的两次密码不一致，请重新输入：");
            }
        }
        System.out.println("请您输入您的取现额度设定：");
        double limit =sc.nextDouble();
        account.setLimit(limit);
        //为账户生成一个卡号，必须是八位数，不能和其他账户的卡号重复
        String newCardId = createCardId();
        account.setCardId(newCardId);
        //3.把这个账户对象，存到账户集合里面去
        accounts.add(account);
        System.out.println("恭喜您，"+ account.getUserName()+"开户成功，您的卡号是："+account.getCardId());
    }
    private String createCardId(){
        while (true) {
            String cardId="";
            Random r = new Random();
            for (int i = 0; i < 8; i++) {
                int data = r.nextInt(10);
                cardId +=data;
            }
            Account acc = getAccountByCardId(cardId);
            if (acc==null)
            {
            return cardId;
            }
        }

    }
    /*根据卡号在账户集合中查找账户*/
    private Account getAccountByCardId(String cardId) {
        //遍历全部的账户对象
        for (int i = 0; i < accounts.size(); i++) {
            Account acc = accounts.get(i);
            //判读账户对象acc的卡号是否是我们要找的
            if (acc.getCardId().equals(cardId)) {
                return acc;
            }
        }
        return null;//查无此账户
    }
}
