package com.atm;

public class Test {
    public static void main(String[] args) {
        //1.创建ATM对象
        ATM atm =new ATM();
        atm.start();
    }


}
